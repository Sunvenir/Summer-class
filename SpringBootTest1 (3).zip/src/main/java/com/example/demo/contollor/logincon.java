package com.example.demo.contollor;

import com.example.demo.Repository.Dao;
import com.example.demo.Repository.DaoImgl;
import com.example.demo.domain.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.Map;


@Controller
public class logincon {
    @RequestMapping(value = "/user/login")
    public String login(@RequestParam("username") String username,
                      @RequestParam("password") String password,
                      Map<String,Object> map, HttpSession session){
        Dao dao = DaoImgl.getInstance();
        User user = dao.login(username,password);
        if(user != null){
            return "login_test";
        }
        else {
            return "login";
        }
    }

    @RequestMapping(value = "/user/register")
    public String register(@RequestParam("username") String username,
                           @RequestParam("password") String password,
                           Map<String,Object> map, HttpSession session){
        User user = new User(username,password);
        Dao dao = DaoImgl.getInstance();
        dao.register(user);
        return "login";
    }
}
